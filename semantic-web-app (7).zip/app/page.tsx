import { AppContent } from "@/components/app-content"

export default function Home() {
  return <AppContent />
}
