"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { RdfGraphView } from "@/components/rdf-graph-view"
import { Network, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRdfStore } from "@/lib/rdf-store"
import { useToast } from "@/hooks/use-toast"
import { exportAsDot, exportAsGraphML } from "@/lib/export-utils"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function GraphExplorer() {
  const { graph } = useRdfStore()
  const { toast } = useToast()

  const handleExportGraph = (format) => {
    if (!graph) {
      toast({
        title: "Aucune donnée RDF",
        description: "Il n'y a aucune donnée RDF à exporter.",
        variant: "destructive",
      })
      return
    }

    // Convertir le graphe RDF en format pour l'exportation
    const nodes = new Map()
    const links = []

    // Parcourir tous les quads du graphe
    graph.forEach((quad) => {
      // Ajouter le nœud sujet s'il n'existe pas déjà
      if (!nodes.has(quad.subject.value)) {
        nodes.set(quad.subject.value, {
          id: quad.subject.value,
          name: quad.subject.value.split("/").pop() || quad.subject.value.split("#").pop() || quad.subject.value,
          color: "#7209b7",
        })
      }

      // Ajouter le nœud objet s'il n'existe pas déjà et si c'est une URI
      if (quad.object.termType === "NamedNode" && !nodes.has(quad.object.value)) {
        nodes.set(quad.object.value, {
          id: quad.object.value,
          name: quad.object.value.split("/").pop() || quad.object.value.split("#").pop() || quad.object.value,
          color: "#4361ee",
        })
      }

      // Ajouter un lien si l'objet est une URI
      if (quad.object.termType === "NamedNode") {
        links.push({
          source: quad.subject.value,
          target: quad.object.value,
          name: quad.predicate.value.split("/").pop() || quad.predicate.value.split("#").pop() || quad.predicate.value,
        })
      }
    })

    const graphData = {
      nodes: Array.from(nodes.values()),
      links: links,
    }

    try {
      switch (format) {
        case "dot":
          exportAsDot(graphData, "rdf-graph-full.dot")
          break
        case "graphml":
          exportAsGraphML(graphData, "rdf-graph-full.graphml")
          break
        default:
          throw new Error(`Format d'exportation de graphe non pris en charge: ${format}`)
      }

      toast({
        title: "Exportation réussie",
        description: `Le graphe RDF complet a été exporté au format ${format.toUpperCase()}.`,
      })
    } catch (error) {
      console.error("Graph export error:", error)
      toast({
        title: "Erreur d'exportation",
        description: error.message || "Une erreur s'est produite lors de l'exportation du graphe.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Explorateur de Graphe RDF</h1>

        {graph && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Exporter le Graphe Complet
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => handleExportGraph("dot")}>
                <span>Exporter en DOT (Graphviz)</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportGraph("graphml")}>
                <span>Exporter en GraphML</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold flex items-center">
            <Network className="h-6 w-6 mr-2" />
            Visualisation du Graphe RDF
          </CardTitle>
          <CardDescription>
            Visualisation graphique de l'ensemble des données RDF chargées dans l'application
          </CardDescription>
        </CardHeader>
        <CardContent>
          <RdfGraphView />
        </CardContent>
      </Card>
    </div>
  )
}
