"use client"

import { useState, useEffect, useRef } from "react"
import dynamic from "next/dynamic"
import { useToast } from "@/hooks/use-toast"
import { GraphLegend } from "@/components/graph-legend"
import { useBrowser } from "@/hooks/use-browser"
import { FileText } from "lucide-react"

// Dynamically import ForceGraph3D with no SSR
const ForceGraph3D = dynamic(() => import("react-force-graph-3d"), { ssr: false })

// Remplacer la fonction ResultsGraphView par cette version simplifiée
export function ResultsGraphView({ results }) {
  const { toast } = useToast()
  const [graphData, setGraphData] = useState({ nodes: [], links: [] })
  const isBrowser = useBrowser()
  const graphRef = useRef()

  // Effet pour traiter les résultats et générer les données du graphe
  useEffect(() => {
    if (!isBrowser) return

    if (
      !results ||
      !results.head ||
      !results.results ||
      !results.results.bindings ||
      results.results.bindings.length === 0
    ) {
      console.log("No valid results to display in graph view")
      setGraphData({ nodes: [], links: [] })
      return
    }

    try {
      console.log("Processing results for graph view:", results)

      // Créer un graphe simple à partir des résultats
      const nodes = new Map()
      const links = []

      // Obtenir les variables de la requête
      const vars = results.head.vars || []
      const bindings = results.results.bindings || []

      // Créer un nœud central pour chaque résultat
      bindings.forEach((row, rowIndex) => {
        const resultId = `result_${rowIndex}`

        // Ajouter le nœud de résultat
        nodes.set(resultId, {
          id: resultId,
          name: `Résultat ${rowIndex + 1}`,
          color: "#4cc9f0",
          val: 2,
        })

        // Ajouter un nœud pour chaque valeur et le connecter au résultat
        vars.forEach((varName) => {
          if (row[varName]) {
            const value = row[varName].value
            const valueId = `${varName}_${value}_${rowIndex}`

            // Ajouter le nœud de valeur
            nodes.set(valueId, {
              id: valueId,
              name: value.split("/").pop() || value.split("#").pop() || value,
              color: row[varName].type === "uri" ? "#7209b7" : "#f72585",
              val: 1,
            })

            // Connecter le résultat à la valeur
            links.push({
              source: resultId,
              target: valueId,
              name: varName,
            })
          }
        })
      })

      // Mettre à jour les données du graphe
      setGraphData({
        nodes: Array.from(nodes.values()),
        links: links,
      })

      console.log(`Created graph with ${nodes.size} nodes and ${links.length} links`)
    } catch (error) {
      console.error("Error creating graph from results:", error)
      toast({
        title: "Erreur de visualisation",
        description: "Impossible de générer la visualisation graphique des résultats.",
        variant: "destructive",
      })
      setGraphData({ nodes: [], links: [] })
    }
  }, [results, isBrowser, toast])

  // Si pas de résultats ou pas de données de graphe
  if (!results || graphData.nodes.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[400px] bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-dashed border-slate-300 dark:border-slate-600">
        <FileText className="h-12 w-12 text-slate-300 mb-4" />
        <p className="text-slate-600 dark:text-slate-300 text-center max-w-xs">
          Aucune donnée à visualiser ou impossible de générer un graphe à partir des résultats.
        </p>
      </div>
    )
  }

  // Rendu du graphe
  return (
    <div className="relative h-[400px]">
      <div className="absolute top-2 right-2 z-10">
        <GraphLegend />
      </div>
      <div className="h-full rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700">
        {isBrowser && (
          <ForceGraph3D
            ref={graphRef}
            graphData={graphData}
            nodeLabel={(node) => node.name}
            linkLabel={(link) => link.name}
            nodeColor="color"
            backgroundColor="#ffffff"
            linkColor={() => "#4cc9f0"}
            linkWidth={1.5}
            nodeRelSize={6}
          />
        )}
      </div>
    </div>
  )
}
