"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useRdfStore } from "@/lib/rdf-store"
import { Upload, FileCode, Check } from "lucide-react"

export function OntologyLoader() {
  const { toast } = useToast()
  const { loadOntology } = useRdfStore()
  const [file, setFile] = useState(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
    }
  }

  const handleLoadOntology = async () => {
    if (!file) {
      toast({
        title: "Aucun fichier sélectionné",
        description: "Veuillez sélectionner un fichier d'ontologie OWL à charger.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      await loadOntology(file)
      toast({
        title: "Ontologie Chargée",
        description: `Ontologie chargée avec succès depuis ${file.name}`,
      })
    } catch (error) {
      toast({
        title: "Erreur de chargement d'ontologie",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="border border-slate-200 dark:border-slate-700 shadow-lg bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm h-full">
      <CardHeader>
        <CardTitle className="text-2xl font-bold bg-semantic-gradient-alt bg-clip-text text-transparent flex items-center">
          <FileCode className="h-6 w-6 mr-2 text-semantic-purple" />
          Charger une Ontologie OWL
        </CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-300">
          Chargez une ontologie OWL pour activer les capacités de raisonnement
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid w-full items-center gap-2">
          <label htmlFor="owl-file" className="text-sm font-medium text-slate-700 dark:text-slate-300">
            Fichier d'Ontologie OWL
          </label>
          <div className="flex flex-col gap-2">
            {file ? (
              <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 flex items-center justify-between">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-semantic-purple/10 flex items-center justify-center mr-3">
                    <Check className="h-5 w-5 text-semantic-purple" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">{file.name}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{(file.size / 1024).toFixed(2)} KB</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={() => setFile(null)} className="text-xs h-8">
                  Changer
                </Button>
              </div>
            ) : (
              <Button
                variant="outline"
                onClick={() => document.getElementById("owl-file").click()}
                className="h-24 border-dashed border-2 flex flex-col gap-2 hover:border-semantic-purple hover:text-semantic-purple transition-colors"
              >
                <Upload className="h-6 w-6" />
                <span>Choisir un fichier</span>
              </Button>
            )}
            <input
              id="owl-file"
              type="file"
              className="hidden"
              onChange={handleFileChange}
              accept=".owl,.rdf,.xml,.ttl"
            />
          </div>
        </div>

        <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50">
          <h4 className="font-medium text-sm mb-2">Qu'est-ce que le raisonnement OWL?</h4>
          <p className="text-xs text-slate-600 dark:text-slate-300">
            Le raisonnement OWL permet de déduire de nouvelles connaissances à partir de votre ontologie et de vos
            données RDF. Cela permet d'inférer des relations implicites, de vérifier la cohérence et d'enrichir vos
            requêtes SPARQL.
          </p>
        </div>
      </CardContent>
      <CardFooter>
        <Button
          onClick={handleLoadOntology}
          disabled={!file || isLoading}
          className="w-full bg-semantic-gradient-alt hover:opacity-90 transition-opacity"
        >
          {isLoading ? "Chargement..." : "Charger l'Ontologie"}
        </Button>
      </CardFooter>
    </Card>
  )
}
