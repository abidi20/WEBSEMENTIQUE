"use client"

import Link from "next/link"
import { Network } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRdfStore } from "@/lib/rdf-store"

export function GraphExplorerLink() {
  const { graph } = useRdfStore()

  if (!graph || graph.size === 0) {
    return (
      <Button disabled variant="outline" className="opacity-50">
        <Network className="h-4 w-4 mr-2" />
        Explorateur de Graphes
      </Button>
    )
  }

  return (
    <Link href="/graph-explorer" passHref>
      <Button
        variant="outline"
        className="data-[state=active]:bg-semantic-gradient data-[state=active]:text-white rounded-lg transition-all h-10 px-4 gap-2"
      >
        <Network className="h-4 w-4" />
        Explorateur de Graphes
      </Button>
    </Link>
  )
}
