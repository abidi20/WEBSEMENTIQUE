"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { useClientRdfStore } from "@/lib/rdf-store"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Globe, Database, CheckCircle2, AlertCircle, Info, Shield, LogOut } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useBrowser } from "@/hooks/use-browser"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export function EndpointConnector() {
  const { toast } = useToast()
  const { connectToEndpoint, currentEndpoint, disconnectEndpoint } = useClientRdfStore()
  const [endpointUrl, setEndpointUrl] = useState("")
  const [isConnecting, setIsConnecting] = useState(false)
  const [selectedPreset, setSelectedPreset] = useState("")
  const [error, setError] = useState("")
  const [errorDetails, setErrorDetails] = useState("")
  const [useCorsProxy, setUseCorsProxy] = useState(false)
  const isBrowser = useBrowser()

  const presetEndpoints = [
    { name: "DBpedia", url: "https://dbpedia.org/sparql", description: "Base de connaissances extraite de Wikipedia" },
    {
      name: "Wikidata",
      url: "https://query.wikidata.org/sparql",
      description: "Base de connaissances structurées collaborative",
    },
    { name: "Bio2RDF", url: "http://bio2rdf.org/sparql", description: "Données biologiques liées" },
    {
      name: "LinkedGeoData",
      url: "http://linkedgeodata.org/sparql",
      description: "Données géographiques d'OpenStreetMap",
    },
  ]

  const handlePresetChange = (value) => {
    setSelectedPreset(value)
    const preset = presetEndpoints.find((p) => p.name === value)
    if (preset) {
      setEndpointUrl(preset.url)
      setError("") // Réinitialiser les erreurs précédentes
      setErrorDetails("")
    }
  }

  const handleConnect = async () => {
    if (!isBrowser) {
      toast({
        title: "Erreur",
        description: "Cette fonctionnalité n'est disponible que dans le navigateur.",
        variant: "destructive",
      })
      return
    }

    if (!endpointUrl.trim()) {
      toast({
        title: "URL vide",
        description: "Veuillez entrer une URL d'endpoint SPARQL.",
        variant: "destructive",
      })
      return
    }

    setIsConnecting(true)
    setError("") // Réinitialiser les erreurs précédentes
    setErrorDetails("")

    try {
      await connectToEndpoint(endpointUrl, useCorsProxy)
      toast({
        title: "Connecté",
        description: `Connexion réussie à ${endpointUrl}`,
      })
    } catch (error) {
      console.error("Connection error:", error)

      // Extraire le message d'erreur principal
      const errorMessage = error.message || "Erreur de connexion à l'endpoint SPARQL"

      // Déterminer si c'est une erreur CORS
      const isCorsError =
        errorMessage.includes("CORS") ||
        errorMessage.includes("cross-origin") ||
        errorMessage.includes("Cross-Origin") ||
        errorMessage.includes("blocked by CORS policy") ||
        errorMessage.includes("Failed to fetch") ||
        errorMessage.includes("NetworkError")

      // Définir le message d'erreur principal
      setError(isCorsError ? "Erreur CORS: L'endpoint n'autorise pas les requêtes depuis cette origine" : errorMessage)

      // Ajouter des détails supplémentaires pour aider l'utilisateur
      setErrorDetails(
        isCorsError
          ? "Essayez d'activer l'option 'Utiliser un proxy CORS' ci-dessous pour contourner cette restriction."
          : "Vérifiez que l'URL est correcte et que l'endpoint est accessible.",
      )

      toast({
        title: "Erreur de connexion",
        description: isCorsError
          ? "Erreur CORS: L'endpoint n'autorise pas les requêtes depuis cette origine"
          : errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  // Fonction pour se déconnecter de l'endpoint
  const handleDisconnect = () => {
    disconnectEndpoint()
    toast({
      title: "Déconnecté",
      description: "Vous avez été déconnecté de l'endpoint SPARQL.",
    })
  }

  return (
    <Card className="glass card-hover border-white/20 dark:border-slate-700/50 shadow-lg">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl font-bold bg-semantic-gradient bg-clip-text text-transparent flex items-center">
          <div className="h-10 w-10 rounded-full bg-semantic-teal/10 flex items-center justify-center mr-3 glow">
            <Globe className="h-6 w-6 text-semantic-teal" />
          </div>
          Connecteur d'Endpoint SPARQL
        </CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-300">
          Connectez-vous à un endpoint SPARQL distant pour interroger et explorer les données
          {currentEndpoint && (
            <div className="mt-2 flex items-center">
              <Badge className="bg-semantic-green text-white shadow-glow-sm animate-pulse-slow">
                <CheckCircle2 className="h-3 w-3 mr-1" />
                Connecté
              </Badge>
              <span className="ml-2 text-sm font-medium">{currentEndpoint}</span>

              {/* Bouton de déconnexion */}
              <Button
                variant="outline"
                size="sm"
                onClick={handleDisconnect}
                className="ml-auto bg-red-50 hover:bg-red-100 text-red-600 border-red-200"
              >
                <LogOut className="h-3 w-3 mr-1" />
                Déconnecter
              </Button>
            </div>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <Alert
            variant="destructive"
            className="border-red-200 bg-red-50 dark:bg-red-900/20 dark:border-red-800/30 animated-border"
          >
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Erreur de connexion</AlertTitle>
            <AlertDescription>
              {error}
              {errorDetails && (
                <div className="mt-2 text-sm flex items-start gap-1">
                  <Info className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>{errorDetails}</span>
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}

        <div className="grid w-full items-center gap-2">
          <label
            htmlFor="preset-endpoint"
            className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-2"
          >
            <Database className="h-4 w-4 text-semantic-purple" />
            Endpoints Prédéfinis
          </label>
          <Select value={selectedPreset} onValueChange={handlePresetChange}>
            <SelectTrigger
              id="preset-endpoint"
              className="bg-white/70 dark:bg-slate-800/70 border-slate-200/50 dark:border-slate-700/50 backdrop-blur-sm"
            >
              <SelectValue placeholder="Sélectionner un endpoint prédéfini" />
            </SelectTrigger>
            <SelectContent>
              {presetEndpoints.map((preset) => (
                <SelectItem key={preset.name} value={preset.name}>
                  <div className="flex flex-col">
                    <span className="font-medium">{preset.name}</span>
                    <span className="text-xs text-slate-500 dark:text-slate-400">{preset.description}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid w-full items-center gap-2">
          <label
            htmlFor="endpoint-url"
            className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-2"
          >
            <Globe className="h-4 w-4 text-semantic-blue" />
            URL de l'Endpoint SPARQL
          </label>
          <div className="flex items-center">
            <div className="bg-slate-100/70 dark:bg-slate-700/70 p-2 rounded-l-md border border-r-0 border-slate-200/50 dark:border-slate-600/50 backdrop-blur-sm">
              <Database className="h-5 w-5 text-slate-500 dark:text-slate-400" />
            </div>
            <Input
              id="endpoint-url"
              placeholder="https://example.org/sparql"
              value={endpointUrl}
              onChange={(e) => setEndpointUrl(e.target.value)}
              className="rounded-l-none bg-white/70 dark:bg-slate-800/70 border-slate-200/50 dark:border-slate-700/50 backdrop-blur-sm"
            />
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Switch id="use-cors-proxy" checked={useCorsProxy} onCheckedChange={setUseCorsProxy} />
          <Label htmlFor="use-cors-proxy" className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-semantic-purple" />
            <span>Utiliser un proxy CORS</span>
            <Badge variant="outline" className="ml-1 text-xs">
              Recommandé
            </Badge>
          </Label>
        </div>

        <div className="p-4 rounded-lg border border-slate-200/50 dark:border-slate-700/50 bg-white/30 dark:bg-slate-800/30 backdrop-blur-sm">
          <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
            <div className="h-5 w-5 rounded-full bg-semantic-blue/10 flex items-center justify-center">
              <Globe className="h-3 w-3 text-semantic-blue" />
            </div>
            Qu'est-ce qu'un endpoint SPARQL?
          </h4>
          <p className="text-xs text-slate-600 dark:text-slate-300">
            Un endpoint SPARQL est un service web qui permet d'interroger une base de données RDF en utilisant le
            langage de requête SPARQL. Il vous donne accès à de vastes ensembles de données du Web Sémantique sans avoir
            à les télécharger localement.
          </p>
          <div className="mt-2 text-xs text-slate-600 dark:text-slate-300">
            <p className="font-medium">Note sur les erreurs CORS:</p>
            <p>
              Certains endpoints SPARQL peuvent bloquer les requêtes provenant d'applications web en raison des
              restrictions CORS. Si vous rencontrez des erreurs CORS, activez l'option "Utiliser un proxy CORS" pour
              contourner ces restrictions.
            </p>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        {!currentEndpoint ? (
          <Button
            onClick={handleConnect}
            disabled={!endpointUrl.trim() || isConnecting || !isBrowser}
            className="w-full bg-semantic-gradient hover:opacity-90 transition-opacity shadow-glow-sm"
          >
            {isConnecting ? (
              <div className="flex items-center gap-2">
                <div className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                <span>Connexion en cours...</span>
              </div>
            ) : (
              "Se connecter à l'Endpoint"
            )}
          </Button>
        ) : (
          <Button
            onClick={handleDisconnect}
            className="w-full bg-red-500 hover:bg-red-600 text-white transition-colors"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Déconnecter de l'Endpoint
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
