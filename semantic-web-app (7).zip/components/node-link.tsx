"use client"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"

export function NodeLink({ nodeUri, children, className = "" }) {
  const router = useRouter()

  const handleClick = (e) => {
    e.preventDefault()
    e.stopPropagation()

    // Encoder l'URI du nœud pour l'URL
    const encodedUri = encodeURIComponent(nodeUri)
    router.push(`/node-explorer/${encodedUri}`)
  }

  return (
    <Button variant="link" className={`p-0 h-auto ${className}`} onClick={handleClick}>
      {children || nodeUri.split("/").pop() || nodeUri.split("#").pop() || nodeUri}
      <ExternalLink className="h-3 w-3 ml-1" />
    </Button>
  )
}
