"use client"

import { useState, useEffect, useRef, forwardRef, useImperativeHandle } from "react"
import dynamic from "next/dynamic"
import { useBrowser } from "@/hooks/use-browser"
import { useRdfStore } from "@/lib/rdf-store"
import { Button } from "@/components/ui/button"
import { ZoomIn, ZoomOut, RotateCcw } from "lucide-react"
import { exportAsDot, exportAsGraphML } from "@/lib/export-utils"
import { useToast } from "@/hooks/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useRouter } from "next/navigation"

// Dynamically import ForceGraph2D with no SSR
const ForceGraph2D = dynamic(() => import("react-force-graph-2d"), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-full bg-slate-50 dark:bg-slate-800/50 rounded-lg">
      <div className="h-8 w-8 rounded-full border-4 border-semantic-purple border-t-transparent animate-spin"></div>
    </div>
  ),
})

// Modification de la signature du composant pour accepter onNodeClick
const RdfGraphView = forwardRef(({ onLoadData, onNodeClick }, ref) => {
  const { graph, setSelectedNode } = useRdfStore()
  const { toast } = useToast()
  const router = useRouter()
  const [graphData, setGraphData] = useState({ nodes: [], links: [] })
  const isBrowser = useBrowser()
  const graphRef = useRef()
  const prevGraphRef = useRef(null)

  // Exposer des méthodes au composant parent
  useImperativeHandle(ref, () => ({
    searchNode: (searchTerm) => {
      if (!graphRef.current || !graphData.nodes || graphData.nodes.length === 0) {
        toast({
          title: "Recherche impossible",
          description: "Aucune donnée de graphe n'est disponible pour la recherche.",
          variant: "destructive",
        })
        return false
      }

      const searchTermLower = searchTerm.toLowerCase()
      const node = graphData.nodes.find(
        (n) =>
          (n.id && n.id.toLowerCase().includes(searchTermLower)) ||
          (n.name && n.name.toLowerCase().includes(searchTermLower)),
      )

      if (node) {
        // Centrer sur le nœud trouvé
        graphRef.current.centerAt(node.x, node.y, 1000)
        graphRef.current.zoom(2, 1000)

        // Sélectionner le nœud
        handleNodeClick(node)

        toast({
          title: "Nœud trouvé",
          description: `Le nœud "${node.name || node.id}" a été trouvé et sélectionné.`,
        })

        return true
      } else {
        toast({
          title: "Nœud non trouvé",
          description: `Aucun nœud correspondant à "${searchTerm}" n'a été trouvé.`,
          variant: "destructive",
        })
        return false
      }
    },
    resetView: () => {
      if (graphRef.current) {
        graphRef.current.zoomToFit(400)
        return true
      }
      return false
    },
  }))

  useEffect(() => {
    if (!isBrowser || !graph) return

    // Vérifier si le graphe a changé pour éviter les traitements inutiles
    if (prevGraphRef.current === graph) return
    prevGraphRef.current = graph

    try {
      console.log("Processing RDF graph for visualization")

      // Convertir le graphe RDF en format pour la visualisation
      const nodes = new Map()
      const links = []

      // Parcourir tous les quads du graphe
      graph.forEach((quad) => {
        // Ajouter le nœud sujet s'il n'existe pas déjà
        if (!nodes.has(quad.subject.value)) {
          nodes.set(quad.subject.value, {
            id: quad.subject.value,
            name: quad.subject.value.split("/").pop() || quad.subject.value.split("#").pop() || quad.subject.value,
            color: "#7209b7", // Violet pour les sujets
            size: 8,
          })
        }

        // Ajouter le nœud objet s'il n'existe pas déjà et si c'est une URI
        if (quad.object.termType === "NamedNode" && !nodes.has(quad.object.value)) {
          nodes.set(quad.object.value, {
            id: quad.object.value,
            name: quad.object.value.split("/").pop() || quad.object.value.split("#").pop() || quad.object.value,
            color: "#4361ee", // Bleu pour les objets
            size: 8,
          })
        }

        // Ajouter un lien si l'objet est une URI
        if (quad.object.termType === "NamedNode") {
          links.push({
            source: quad.subject.value,
            target: quad.object.value,
            name:
              quad.predicate.value.split("/").pop() || quad.predicate.value.split("#").pop() || quad.predicate.value,
          })
        }
      })

      console.log(`Created RDF graph visualization with ${nodes.size} nodes and ${links.length} links`)

      // Limiter le nombre de nœuds et de liens pour éviter les problèmes de performance
      const maxNodes = 500
      const maxLinks = 1000

      let nodesArray = Array.from(nodes.values())
      let linksArray = links

      if (nodesArray.length > maxNodes) {
        console.log(`Limiting nodes from ${nodesArray.length} to ${maxNodes}`)
        nodesArray = nodesArray.slice(0, maxNodes)

        // Filtrer les liens pour ne garder que ceux qui concernent les nœuds conservés
        const nodeIds = new Set(nodesArray.map((node) => node.id))
        linksArray = links.filter((link) => nodeIds.has(link.source) && nodeIds.has(link.target)).slice(0, maxLinks)
      } else if (linksArray.length > maxLinks) {
        console.log(`Limiting links from ${linksArray.length} to ${maxLinks}`)
        linksArray = linksArray.slice(0, maxLinks)
      }

      // Mettre à jour l'état avec les nouvelles données
      setGraphData({
        nodes: nodesArray,
        links: linksArray,
      })
    } catch (error) {
      console.error("Error creating RDF graph visualization:", error)
      setGraphData({ nodes: [], links: [] })
    }
  }, [graph, isBrowser, toast]) // Retirer graphData des dépendances

  const handleZoomIn = () => {
    if (graphRef.current) {
      const currentZoom = graphRef.current.zoom()
      graphRef.current.zoom(currentZoom * 1.5, 400)
    }
  }

  const handleZoomOut = () => {
    if (graphRef.current) {
      const currentZoom = graphRef.current.zoom()
      graphRef.current.zoom(currentZoom / 1.5, 400)
    }
  }

  const handleReset = () => {
    if (graphRef.current) {
      graphRef.current.zoomToFit(400)
    }
  }

  // Modification de la fonction handleNodeClick
  const handleNodeClick = (node) => {
    console.log("Node clicked in RdfGraphView:", node)

    // Mettre à jour le nœud sélectionné dans le store
    setSelectedNode(node.id)

    // Appeler la fonction onNodeClick si elle existe
    if (onNodeClick) {
      onNodeClick(node)
    }

    // Récupérer explicitement la CBD du nœud
    try {
      const { getNodeCBD } = useRdfStore.getState()
      getNodeCBD(node.id)

      toast({
        title: "Nœud sélectionné",
        description: `Détails chargés pour ${node.name || node.id.split("/").pop() || node.id}`,
      })
    } catch (error) {
      console.error("Error getting node CBD:", error)
      toast({
        title: "Erreur",
        description: "Impossible de charger les détails du nœud",
        variant: "destructive",
      })
    }
  }

  if (!isBrowser || !graph || graphData.nodes.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-dashed border-slate-300 dark:border-slate-600">
        <div className="w-16 h-16 mb-4 rounded-full bg-semantic-purple/10 flex items-center justify-center animate-pulse-slow">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="text-semantic-purple"
          >
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="2" y1="12" x2="22" y2="12"></line>
            <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
          </svg>
        </div>
        <p className="text-slate-600 dark:text-slate-300 text-center max-w-xs mb-4">
          Aucune donnée de graphe chargée.
          <br />
          Veuillez charger un fichier RDF ou vous connecter à un endpoint SPARQL.
        </p>
        <Button
          variant="outline"
          className="bg-white/50 dark:bg-slate-800/50 hover:bg-semantic-purple hover:text-white transition-colors"
          onClick={onLoadData || (() => router.push("/?tab=load"))}
        >
          Charger des données
        </Button>
      </div>
    )
  }

  return (
    <div className="relative h-full border rounded-lg overflow-hidden">
      <div className="absolute top-2 right-2 z-10 flex gap-1">
        <Button
          variant="outline"
          size="icon"
          onClick={handleZoomIn}
          className="bg-white/80 dark:bg-slate-800/80 h-8 w-8"
        >
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={handleZoomOut}
          className="bg-white/80 dark:bg-slate-800/80 h-8 w-8"
        >
          <ZoomOut className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={handleReset}
          className="bg-white/80 dark:bg-slate-800/80 h-8 w-8"
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="bg-white/80 dark:bg-slate-800/80 h-8 w-8">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
              </svg>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            <DropdownMenuItem onClick={() => exportAsDot(graphData, "rdf-graph.dot")}>
              <span>Exporter en DOT (Graphviz)</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => exportAsGraphML(graphData, "rdf-graph.graphml")}>
              <span>Exporter en GraphML</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="absolute bottom-2 left-2 z-10 bg-white/80 dark:bg-slate-800/80 px-2 py-1 rounded text-xs">
        {graphData.nodes.length} nœuds, {graphData.links.length} liens
        {graph.size > graphData.nodes.length + graphData.links.length && ` (limité, total: ${graph.size} triplets)`}
      </div>

      <ForceGraph2D
        ref={graphRef}
        graphData={graphData}
        nodeLabel="name"
        linkLabel="name"
        nodeColor="color"
        nodeVal="size"
        linkDirectionalArrowLength={3}
        linkDirectionalArrowRelPos={1}
        backgroundColor="#ffffff"
        linkColor={() => "#4cc9f0"}
        onNodeClick={handleNodeClick}
        onLinkClick={(link) => console.log("Link clicked:", link)}
        cooldownTicks={100}
        onEngineStop={() => console.log("Graph physics stabilized")}
      />
    </div>
  )
})

RdfGraphView.displayName = "RdfGraphView"

export { RdfGraphView }
