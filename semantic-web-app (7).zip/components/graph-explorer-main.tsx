"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useRdfStore } from "@/lib/rdf-store"
import { NodeDetails } from "@/components/node-details"
import { RdfGraphView } from "@/components/rdf-graph-view"
import { Search, RotateCcw, Maximize2 } from "lucide-react"
import { useBrowser } from "@/hooks/use-browser"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

export function GraphExplorer() {
  const { graph, selectedNode, getNodeCBD } = useRdfStore()
  const { toast } = useToast()
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState("")
  const [isFullscreen, setIsFullscreen] = useState(false)
  const graphRef = useRef()

  const isBrowser = useBrowser()

  // Effet pour rafraîchir les détails du nœud sélectionné
  useEffect(() => {
    if (selectedNode && isBrowser) {
      console.log("Refreshing CBD for selected node:", selectedNode)
      getNodeCBD(selectedNode)
    }
  }, [selectedNode, isBrowser, getNodeCBD])

  const handleSearch = () => {
    if (!searchTerm) {
      toast({
        title: "Terme de recherche vide",
        description: "Veuillez entrer un terme à rechercher.",
        variant: "destructive",
      })
      return
    }

    if (!graph || graph.size === 0) {
      toast({
        title: "Aucune donnée",
        description: "Aucune donnée de graphe n'est chargée pour effectuer la recherche.",
        variant: "destructive",
      })
      return
    }

    // Rechercher le nœud dans le graphe
    try {
      if (graphRef.current && graphRef.current.searchNode) {
        const found = graphRef.current.searchNode(searchTerm)
        if (!found) {
          toast({
            title: "Nœud non trouvé",
            description: `Aucun nœud correspondant à "${searchTerm}" n'a été trouvé.`,
            variant: "destructive",
          })
        }
      } else {
        toast({
          title: "Recherche non disponible",
          description: "La fonctionnalité de recherche n'est pas disponible actuellement.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Search error:", error)
      toast({
        title: "Erreur de recherche",
        description: error.message || "Une erreur s'est produite lors de la recherche.",
        variant: "destructive",
      })
    }
  }

  const handleReset = () => {
    if (graphRef.current && graphRef.current.resetView) {
      graphRef.current.resetView()
    }
  }

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const handleLoadData = () => {
    router.push("/?tab=load")
  }

  if (!isBrowser) {
    return (
      <div className="flex items-center justify-center h-[500px] bg-slate-50 dark:bg-slate-800/50 rounded-lg">
        <div className="h-8 w-8 rounded-full border-4 border-semantic-purple border-t-transparent animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="md:col-span-2">
        <Card className="border border-slate-200 dark:border-slate-700 shadow-lg bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-2xl font-bold text-semantic-purple">Visualisation du Graphe RDF</h2>
                <p className="text-slate-600 dark:text-slate-300">
                  Explorez visuellement le graphe RDF. Cliquez sur les nœuds pour voir les détails.
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon" onClick={handleReset} className="rounded-full h-8 w-8">
                  <RotateCcw className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={toggleFullscreen} className="rounded-full h-8 w-8">
                  <Maximize2 className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex gap-2 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Rechercher un nœud..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  className="pl-9 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                />
              </div>
              <Button onClick={handleSearch} className="bg-semantic-purple hover:bg-semantic-purple/90 text-white">
                Rechercher
              </Button>
            </div>

            <div className={isFullscreen ? "h-[600px]" : "h-[500px]"}>
              <RdfGraphView
                ref={graphRef}
                onLoadData={handleLoadData}
                onNodeClick={(node) => {
                  console.log("Node clicked in parent:", node)
                  getNodeCBD(node.id)
                }}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="md:col-span-1">
        <NodeDetails />
      </div>
    </div>
  )
}
