"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { Copy, Check, Shield } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function CorsProxyHelper() {
  const { toast } = useToast()
  const [proxyUrl, setProxyUrl] = useState("https://corsproxy.io/?")
  const [targetUrl, setTargetUrl] = useState("")
  const [fullUrl, setFullUrl] = useState("")
  const [copied, setCopied] = useState(false)

  const generateProxyUrl = () => {
    if (!targetUrl) {
      toast({
        title: "URL cible manquante",
        description: "Veuillez entrer une URL cible pour générer l'URL du proxy.",
        variant: "destructive",
      })
      return
    }

    const encodedUrl = encodeURIComponent(targetUrl)
    const fullProxyUrl = `${proxyUrl}${encodedUrl}`
    setFullUrl(fullProxyUrl)
  }

  const copyToClipboard = () => {
    if (!fullUrl) return

    navigator.clipboard
      .writeText(fullUrl)
      .then(() => {
        setCopied(true)
        toast({
          title: "URL copiée",
          description: "L'URL du proxy a été copiée dans le presse-papiers.",
        })
        setTimeout(() => setCopied(false), 2000)
      })
      .catch((err) => {
        toast({
          title: "Erreur de copie",
          description: "Impossible de copier l'URL dans le presse-papiers.",
          variant: "destructive",
        })
      })
  }

  return (
    <Card className="glass card-hover border-white/20 dark:border-slate-700/50 shadow-lg">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-bold bg-semantic-gradient-alt bg-clip-text text-transparent flex items-center">
          <div className="h-8 w-8 rounded-full bg-semantic-pink/10 flex items-center justify-center mr-2 glow">
            <Shield className="h-4 w-4 text-semantic-pink" />
          </div>
          Assistant Proxy CORS
        </CardTitle>
        <CardDescription className="text-slate-600 dark:text-slate-300">
          Générez une URL de proxy CORS pour contourner les restrictions CORS des endpoints SPARQL
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800/30">
          <AlertDescription className="text-sm">
            Utilisez un proxy CORS pour accéder aux endpoints SPARQL qui bloquent les requêtes cross-origin. L'URL
            générée peut être utilisée comme URL d'endpoint dans l'application.
          </AlertDescription>
        </Alert>

        <div className="grid w-full items-center gap-2">
          <label htmlFor="proxy-url" className="text-sm font-medium text-slate-700 dark:text-slate-300">
            URL du Proxy CORS
          </label>
          <Input
            id="proxy-url"
            placeholder="https://corsproxy.io/?"
            value={proxyUrl}
            onChange={(e) => setProxyUrl(e.target.value)}
            className="bg-white/70 dark:bg-slate-800/70 border-slate-200/50 dark:border-slate-700/50"
          />
        </div>

        <div className="grid w-full items-center gap-2">
          <label htmlFor="target-url" className="text-sm font-medium text-slate-700 dark:text-slate-300">
            URL de l'Endpoint SPARQL
          </label>
          <Input
            id="target-url"
            placeholder="https://dbpedia.org/sparql"
            value={targetUrl}
            onChange={(e) => setTargetUrl(e.target.value)}
            className="bg-white/70 dark:bg-slate-800/70 border-slate-200/50 dark:border-slate-700/50"
          />
        </div>

        {fullUrl && (
          <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-800 rounded-md border border-slate-200 dark:border-slate-700">
            <div className="flex justify-between items-center">
              <label className="text-xs font-medium text-slate-500 dark:text-slate-400">URL du Proxy Générée</label>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={copyToClipboard}>
                {copied ? <Check className="h-3 w-3 text-green-500" /> : <Copy className="h-3 w-3" />}
              </Button>
            </div>
            <p className="text-xs mt-1 break-all font-mono">{fullUrl}</p>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button
          onClick={generateProxyUrl}
          className="w-full bg-semantic-gradient-alt hover:opacity-90 transition-opacity"
        >
          Générer l'URL du Proxy
        </Button>
      </CardFooter>
    </Card>
  )
}
