"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SparqlEditor } from "@/components/sparql-editor"
import { RdfLoader } from "@/components/rdf-loader"
import { EndpointConnector } from "@/components/endpoint-connector"
import { OntologyLoader } from "@/components/ontology-loader"
import { GraphExplorer } from "@/components/graph-explorer-main"
import { CorsProxyHelper } from "@/components/cors-proxy-helper"
import { Database, Code, FileText, Network } from "lucide-react"
import { useRouter, useSearchParams } from "next/navigation"

export function AppContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const tabParam = searchParams?.get("tab")
  const [activeTab, setActiveTab] = useState("explorer")

  // Synchroniser l'onglet actif avec le paramètre d'URL
  useEffect(() => {
    if (tabParam && ["explorer", "query", "load", "endpoints"].includes(tabParam)) {
      setActiveTab(tabParam)
    }
  }, [tabParam])

  // Mettre à jour l'URL lorsque l'onglet change
  const handleTabChange = (value) => {
    setActiveTab(value)
    router.push(`/?tab=${value}`, { scroll: false })
  }

  return (
    <div className="min-h-screen bg-semantic-mesh animated-bg">
      <div className="container mx-auto p-6 pt-6">
        <div className="glass rounded-2xl shadow-xl border border-white/20 dark:border-slate-700/50 overflow-hidden animate-fade-in">
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <div className="border-b border-slate-200/50 dark:border-slate-700/50 px-4 bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm">
              <TabsList className="bg-transparent h-16 w-full justify-start space-x-2">
                <TabsTrigger
                  value="explorer"
                  className="data-[state=active]:bg-semantic-purple data-[state=active]:text-white rounded-lg transition-all h-10 px-4 gap-2"
                >
                  <Network className="h-4 w-4" />
                  Explorateur de Graphes
                </TabsTrigger>
                <TabsTrigger
                  value="query"
                  className="data-[state=active]:bg-semantic-gradient data-[state=active]:text-white rounded-lg transition-all h-10 px-4 gap-2"
                >
                  <Code className="h-4 w-4" />
                  Requêtes SPARQL
                </TabsTrigger>
                <TabsTrigger
                  value="load"
                  className="data-[state=active]:bg-semantic-gradient data-[state=active]:text-white rounded-lg transition-all h-10 px-4 gap-2"
                >
                  <FileText className="h-4 w-4" />
                  Charger des Données
                </TabsTrigger>
                <TabsTrigger
                  value="endpoints"
                  className="data-[state=active]:bg-semantic-gradient data-[state=active]:text-white rounded-lg transition-all h-10 px-4 gap-2"
                >
                  <Database className="h-4 w-4" />
                  Endpoints SPARQL
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="explorer" className="p-6 focus-visible:outline-none focus-visible:ring-0">
              <GraphExplorer />
            </TabsContent>

            <TabsContent value="query" className="p-6 focus-visible:outline-none focus-visible:ring-0">
              <SparqlEditor />
            </TabsContent>

            <TabsContent value="load" className="p-6 focus-visible:outline-none focus-visible:ring-0">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <RdfLoader />
                <OntologyLoader />
              </div>
            </TabsContent>

            <TabsContent value="endpoints" className="p-6 focus-visible:outline-none focus-visible:ring-0">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <EndpointConnector />
                <CorsProxyHelper />
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="mt-8 text-center">
          <div className="inline-flex items-center justify-center space-x-2 bg-white/30 dark:bg-slate-800/30 backdrop-blur-sm px-4 py-2 rounded-full text-sm text-slate-600 dark:text-slate-300">
            <span>© {new Date().getFullYear()} Semantic Web Explorer</span>
            <span className="w-1 h-1 rounded-full bg-slate-400"></span>
            <span>Tous droits réservés</span>
          </div>
        </div>
      </div>
    </div>
  )
}
