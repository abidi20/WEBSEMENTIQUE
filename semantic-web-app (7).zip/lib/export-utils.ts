/**
 * Utilitaires pour l'exportation des résultats dans différents formats
 */

// Fonction pour télécharger un fichier
export function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

// Exporter les résultats au format JSON
export function exportAsJson(results: any, filename = "sparql-results.json") {
  const jsonContent = JSON.stringify(results, null, 2)
  downloadFile(jsonContent, filename, "application/json")
}

// Exporter les résultats au format CSV
export function exportAsCsv(results: any, filename = "sparql-results.csv") {
  if (!results || !results.head || !results.results || !results.results.bindings) {
    throw new Error("Format de résultats invalide pour l'exportation CSV")
  }

  const {
    head,
    results: { bindings },
  } = results
  const vars = head.vars || []

  // Créer l'en-tête CSV
  let csvContent = vars.join(",") + "\n"

  // Ajouter les lignes de données
  bindings.forEach((row) => {
    const csvRow = vars
      .map((variable) => {
        if (row[variable]) {
          // Échapper les guillemets et entourer de guillemets si nécessaire
          const value = row[variable].value.replace(/"/g, '""')
          return `"${value}"`
        }
        return ""
      })
      .join(",")
    csvContent += csvRow + "\n"
  })

  downloadFile(csvContent, filename, "text/csv")
}

// Exporter les résultats au format Turtle (TTL)
export function exportAsTurtle(results: any, filename = "sparql-results.ttl") {
  if (!results || !results.head || !results.results || !results.results.bindings) {
    throw new Error("Format de résultats invalide pour l'exportation Turtle")
  }

  const {
    results: { bindings },
  } = results

  // Créer un préfixe pour notre export
  let turtleContent = `@prefix res: <http://example.org/result/> .\n`
  turtleContent += `@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n`
  turtleContent += `@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\n\n`

  // Convertir les résultats en triplets RDF
  bindings.forEach((row, index) => {
    const subject = `res:result${index + 1}`
    turtleContent += `${subject} rdf:type res:Result .\n`

    // Ajouter les propriétés pour chaque variable
    Object.keys(row).forEach((variable) => {
      if (row[variable]) {
        const predicate = `res:${variable}`
        let object

        // Formater l'objet en fonction du type
        if (row[variable].type === "uri") {
          object = `<${row[variable].value}>`
        } else {
          // Échapper les caractères spéciaux dans les littéraux
          const escapedValue = row[variable].value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n")

          if (row[variable].datatype) {
            object = `"${escapedValue}"^^<${row[variable].datatype}>`
          } else {
            object = `"${escapedValue}"`
          }
        }

        turtleContent += `${subject} ${predicate} ${object} .\n`
      }
    })

    turtleContent += "\n"
  })

  downloadFile(turtleContent, filename, "text/turtle")
}

// Alias pour la compatibilité avec le code existant
export const exportAsRdf = exportAsTurtle

// Exporter le graphe au format DOT (pour Graphviz)
export function exportAsDot(graphData: any, filename = "graph.dot") {
  if (!graphData || !graphData.nodes || !graphData.links) {
    throw new Error("Format de graphe invalide pour l'exportation DOT")
  }

  const { nodes, links } = graphData

  // Créer le contenu DOT
  let dotContent = "digraph G {\n"

  // Ajouter les nœuds
  nodes.forEach((node) => {
    const nodeId = node.id.replace(/[^a-zA-Z0-9_]/g, "_")
    const nodeLabel = node.name || node.id
    dotContent += `  ${nodeId} [label="${nodeLabel}"];\n`
  })

  // Ajouter les liens
  links.forEach((link) => {
    const sourceId = (typeof link.source === "object" ? link.source.id : link.source).replace(/[^a-zA-Z0-9_]/g, "_")
    const targetId = (typeof link.target === "object" ? link.target.id : link.target).replace(/[^a-zA-Z0-9_]/g, "_")
    const linkLabel = link.name || ""
    dotContent += `  ${sourceId} -> ${targetId} [label="${linkLabel}"];\n`
  })

  dotContent += "}\n"

  downloadFile(dotContent, filename, "text/vnd.graphviz")
}

// Exporter le graphe au format GraphML
export function exportAsGraphML(graphData: any, filename = "graph.graphml") {
  if (!graphData || !graphData.nodes || !graphData.links) {
    throw new Error("Format de graphe invalide pour l'exportation GraphML")
  }

  const { nodes, links } = graphData

  // Créer le contenu GraphML
  let graphmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<graphml xmlns="http://graphml.graphdrawing.org/xmlns"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://graphml.graphdrawing.org/xmlns
        http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd">
  <key id="name" for="node" attr.name="name" attr.type="string"/>
  <key id="color" for="node" attr.name="color" attr.type="string"/>
  <key id="label" for="edge" attr.name="label" attr.type="string"/>
  <graph id="G" edgedefault="directed">
`

  // Ajouter les nœuds
  nodes.forEach((node) => {
    graphmlContent += `    <node id="${node.id.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")}">
      <data key="name">${(node.name || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")}</data>
      <data key="color">${node.color || "#000000"}</data>
    </node>
`
  })

  // Ajouter les liens
  links.forEach((link) => {
    const sourceId = (typeof link.source === "object" ? link.source.id : link.source)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
    const targetId = (typeof link.target === "object" ? link.target.id : link.target)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
    graphmlContent += `    <edge source="${sourceId}" target="${targetId}">
      <data key="label">${(link.name || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")}</data>
    </edge>
`
  })

  graphmlContent += `  </graph>
</graphml>`

  downloadFile(graphmlContent, filename, "application/xml")
}

// Exporter les résultats au format N-Triples
export function exportAsNTriples(results: any, filename = "sparql-results.nt") {
  if (!results || !results.head || !results.results || !results.results.bindings) {
    throw new Error("Format de résultats invalide pour l'exportation N-Triples")
  }

  const {
    results: { bindings },
  } = results

  let ntriplesContent = ""

  // Convertir les résultats en triplets N-Triples
  bindings.forEach((row, index) => {
    const subject = `<http://example.org/result/result${index + 1}>`

    // Ajouter un triplet pour le type
    ntriplesContent += `${subject} <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <http://example.org/result/Result> .\n`

    // Ajouter les propriétés pour chaque variable
    Object.keys(row).forEach((variable) => {
      if (row[variable]) {
        const predicate = `<http://example.org/result/${variable}>`
        let object

        // Formater l'objet en fonction du type
        if (row[variable].type === "uri") {
          object = `<${row[variable].value}>`
        } else {
          // Échapper les caractères spéciaux dans les littéraux
          const escapedValue = row[variable].value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n")

          if (row[variable].datatype) {
            object = `"${escapedValue}"^^<${row[variable].datatype}>`
          } else {
            object = `"${escapedValue}"`
          }
        }

        ntriplesContent += `${subject} ${predicate} ${object} .\n`
      }
    })
  })

  downloadFile(ntriplesContent, filename, "application/n-triples")
}

// Exporter les résultats au format JSON-LD
export function exportAsJsonLd(results: any, filename = "sparql-results.jsonld") {
  if (!results || !results.head || !results.results || !results.results.bindings) {
    throw new Error("Format de résultats invalide pour l'exportation JSON-LD")
  }

  const {
    head,
    results: { bindings },
  } = results

  // Créer le contexte JSON-LD
  const jsonld = {
    "@context": {
      res: "http://example.org/result/",
      rdf: "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
      rdfs: "http://www.w3.org/2000/01/rdf-schema#",
      xsd: "http://www.w3.org/2001/XMLSchema#",
    },
    "@graph": [],
  }

  // Convertir les résultats en objets JSON-LD
  bindings.forEach((row, index) => {
    const result = {
      "@id": `res:result${index + 1}`,
      "@type": "res:Result",
    }

    // Ajouter les propriétés pour chaque variable
    Object.keys(row).forEach((variable) => {
      if (row[variable]) {
        if (row[variable].type === "uri") {
          result[`res:${variable}`] = { "@id": row[variable].value }
        } else {
          const value = { "@value": row[variable].value }
          if (row[variable].datatype) {
            value["@type"] = row[variable].datatype
          }
          result[`res:${variable}`] = value
        }
      }
    })

    jsonld["@graph"].push(result)
  })

  const jsonldContent = JSON.stringify(jsonld, null, 2)
  downloadFile(jsonldContent, filename, "application/ld+json")
}
