"use client"

import { create } from "zustand"
import { Parser, Store, DataFactory, type Quad } from "n3"
import { useBrowser } from "@/hooks/use-browser"

// Define the RDF store state
interface RdfState {
  graph: Store | null
  reasoner: any | null
  selectedNode: string | null
  cbd: Quad[] | null
  currentEndpoint: string | null

  // Actions
  loadRdfFromFile: (file: File, format: string) => Promise<void>
  loadOntology: (file: File) => Promise<void>
  executeQuery: (query: string, useReasoning: boolean) => Promise<any>
  connectToEndpoint: (endpointUrl: string, useCorsProxy?: boolean) => Promise<void>
  disconnectEndpoint: () => void // Nouvelle fonction pour se déconnecter
  setSelectedNode: (nodeUri: string | null) => void
  getNodeCBD: (nodeUri: string) => void
  clearGraph: () => void // Nouvelle fonction pour effacer le graphe
}

export const useRdfStore = create<RdfState>((set, get) => ({
  graph: null,
  reasoner: null,
  selectedNode: null,
  cbd: null,
  currentEndpoint: null,

  loadRdfFromFile: async (file, format) => {
    return new Promise<void>((resolve, reject) => {
      const reader = new FileReader()

      reader.onload = async (event) => {
        try {
          const content = event.target?.result as string
          const parser = new Parser({ format: format })

          // Parse the RDF content
          const quads: Quad[] = []
          parser.parse(content, (error, quad, prefixes) => {
            if (error) {
              reject(new Error(`Error parsing RDF: ${error.message}`))
              return
            }

            if (quad) {
              quads.push(quad)
            } else {
              // End of parsing
              const store = new Store(quads)
              // Ajouter les préfixes communs et données d'exemple
              addCommonPrefixes(store)
              set({ graph: store })
              console.log(`Loaded ${quads.length} quads into the graph (plus common prefixes)`)
              resolve()
            }
          })
        } catch (error) {
          console.error("Error loading RDF:", error)
          reject(new Error(`Error loading RDF: ${error.message}`))
        }
      }

      reader.onerror = () => {
        reject(new Error("Error reading file"))
      }

      reader.readAsText(file)
    })
  },

  loadOntology: async (file) => {
    // In a real implementation, this would load the ontology into a reasoner
    // For this example, we'll just parse it as RDF and store it
    return get().loadRdfFromFile(file, "turtle")
  },

  executeQuery: async (query, useReasoning) => {
    const { graph, currentEndpoint } = get()
    console.log("Execute query called with:", { graph: !!graph, currentEndpoint, query })

    // Déterminer le type de requête SPARQL (de manière plus flexible)
    const queryType = getQueryType(query)
    console.log("Detected query type:", queryType)

    if (currentEndpoint) {
      // Execute query against remote endpoint
      try {
        console.log("Executing query against endpoint:", currentEndpoint)

        // Vérifier si nous sommes dans un environnement navigateur
        if (typeof window === "undefined") {
          throw new Error("Cannot execute query on server-side. Please try again on the client.")
        }

        // Utiliser un proxy CORS si nécessaire
        const corsProxy = "" // Laisser vide pour ne pas utiliser de proxy
        const endpointUrl = corsProxy ? `${corsProxy}${encodeURIComponent(currentEndpoint)}` : currentEndpoint

        // Définir les en-têtes en fonction du type de requête
        const headers = {
          "Content-Type": "application/sparql-query",
          Accept: getAcceptHeaderForQueryType(queryType),
        }

        console.log("Using headers:", headers)

        // Essayer d'abord avec POST
        try {
          const response = await fetch(endpointUrl, {
            method: "POST",
            headers: headers,
            body: query,
            mode: "cors",
            credentials: "omit",
          })

          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status} - ${response.statusText}`)
          }

          // Traiter la réponse en fonction du type de requête
          return await processResponse(response, queryType)
        } catch (postError) {
          console.warn("POST request failed, trying GET request:", postError)

          // Si POST échoue, essayons avec GET
          const queryParam = encodeURIComponent(query)
          const getUrl = `${endpointUrl}?query=${queryParam}`

          const getResponse = await fetch(getUrl, {
            method: "GET",
            headers: {
              Accept: getAcceptHeaderForQueryType(queryType),
            },
            mode: "cors",
            credentials: "omit",
          })

          if (!getResponse.ok) {
            throw new Error(`HTTP GET error! status: ${getResponse.status} - ${getResponse.statusText}`)
          }

          // Traiter la réponse en fonction du type de requête
          return await processResponse(getResponse, queryType)
        }
      } catch (error) {
        console.error("Error executing query on endpoint:", error)
        throw new Error(`Error executing query on endpoint: ${error.message}`)
      }
    } else if (graph) {
      // Execute query against local graph
      try {
        console.log("Executing query against local graph with size:", graph.size)

        // Amélioration du traitement des requêtes sur les fichiers Turtle
        // Vérifier si la requête contient des préfixes qui ne sont pas dans le graphe
        const prefixesInQuery = extractPrefixesFromQuery(query)
        const missingPrefixes = findMissingPrefixes(prefixesInQuery, graph)

        if (missingPrefixes.length > 0) {
          console.warn("Missing prefixes in graph:", missingPrefixes)
          // Ajouter les préfixes manquants au graphe
          addMissingPrefixesToGraph(graph, missingPrefixes)
        }

        // Traitement simplifié pour différents types de requêtes
        switch (queryType) {
          case "SELECT":
            return handleLocalSelectQuery(query, graph)
          case "ASK":
            return handleLocalAskQuery(query, graph)
          case "CONSTRUCT":
          case "DESCRIBE":
            return handleLocalConstructQuery(query, graph, queryType)
          case "UPDATE":
            return handleLocalUpdateQuery(query, graph)
          default:
            // Pour les requêtes non reconnues, essayons de les traiter comme SELECT
            console.warn(`Unrecognized query type: ${queryType}, trying to handle as SELECT`)
            return handleLocalSelectQuery(query, graph)
        }
      } catch (error) {
        console.error("Error executing query on local graph:", error)
        throw new Error(`Error executing query on local graph: ${error.message}`)
      }
    } else {
      console.error("No RDF data or endpoint available")
      throw new Error("No RDF data or endpoint available for query execution")
    }
  },

  connectToEndpoint: async (endpointUrl, useCorsProxy = false) => {
    try {
      console.log("Connecting to endpoint:", endpointUrl)

      // Vérifier si nous sommes dans un environnement navigateur
      if (typeof window === "undefined") {
        throw new Error("Cannot connect to endpoint on server-side. Please try again on the client.")
      }

      // Utiliser un proxy CORS si spécifié
      let proxyUrl = endpointUrl
      if (useCorsProxy) {
        const corsProxy = "https://corsproxy.io/?"
        proxyUrl = `${corsProxy}${encodeURIComponent(endpointUrl)}`
        console.log("Using CORS proxy:", proxyUrl)
      }

      // Tester la connexion avec une requête simple
      const testQuery = "SELECT * WHERE { ?s ?p ?o } LIMIT 1"

      try {
        // Première tentative avec POST
        console.log("Trying POST request to endpoint")
        const response = await fetch(proxyUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/sparql-query",
            Accept: "application/sparql-results+json",
          },
          body: testQuery,
          mode: "cors",
          credentials: "omit",
        })

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status} - ${response.statusText}`)
        }

        // Vérifions que la réponse est bien au format JSON
        const data = await response.json()

        if (!data || !data.results) {
          throw new Error("Invalid SPARQL endpoint response format")
        }

        // If successful, update the state
        set({ currentEndpoint: endpointUrl })
        console.log("Successfully connected to endpoint with POST")
        return
      } catch (postError) {
        console.warn("POST request failed, trying GET request:", postError)

        // Si POST échoue, essayons avec GET
        const queryParam = encodeURIComponent(testQuery)
        const getUrl = `${proxyUrl}?query=${queryParam}`

        const getResponse = await fetch(getUrl, {
          method: "GET",
          headers: {
            Accept: "application/sparql-results+json",
          },
          mode: "cors",
          credentials: "omit",
        })

        if (!getResponse.ok) {
          throw new Error(`HTTP GET error! status: ${getResponse.status} - ${getResponse.statusText}`)
        }

        const getData = await getResponse.json()

        if (!getData || !getData.results) {
          throw new Error("Invalid SPARQL endpoint response format from GET request")
        }

        // If successful with GET, update the state
        set({ currentEndpoint: endpointUrl })
        console.log("Successfully connected to endpoint with GET")
        return
      }
    } catch (error) {
      console.error("Failed to connect to endpoint:", error)

      // Déterminer si c'est une erreur CORS
      const errorMessage = error.message || "Unknown error"
      const isCorsError =
        errorMessage.includes("CORS") ||
        errorMessage.includes("cross-origin") ||
        errorMessage.includes("Failed to fetch") ||
        errorMessage.includes("NetworkError") ||
        errorMessage.includes("Network request failed")

      if (isCorsError && !useCorsProxy) {
        throw new Error("CORS error detected. Try using the CORS proxy option.")
      } else {
        throw new Error(`Failed to connect to endpoint: ${errorMessage}`)
      }
    }
  },

  // Nouvelle fonction pour se déconnecter de l'endpoint
  disconnectEndpoint: () => {
    set({ currentEndpoint: null })
    console.log("Disconnected from endpoint")
  },

  // Nouvelle fonction pour effacer le graphe
  clearGraph: () => {
    set({ graph: null, selectedNode: null, cbd: null })
    console.log("Graph cleared")
  },

  setSelectedNode: (nodeUri) => {
    set({ selectedNode: nodeUri })
  },

  getNodeCBD: (nodeUri) => {
    const { graph } = get()

    if (!graph) {
      set({ cbd: null })
      return
    }

    console.log(`Getting CBD for node: ${nodeUri}`)

    try {
      // Implement Concise Bounded Description (CBD)
      // 1. All statements where the subject is the specified node
      // 2. Recursively, for all blank nodes that are objects in the statements, include their CBD

      const cbd: Quad[] = []
      const processed = new Set<string>()
      const toProcess = [nodeUri]

      while (toProcess.length > 0) {
        const current = toProcess.pop()

        if (processed.has(current)) {
          continue
        }

        processed.add(current)

        // Get all statements where current is the subject
        const subjectQuads = graph.getQuads(DataFactory.namedNode(current), null, null, null)
        console.log(`Found ${subjectQuads.length} quads for subject ${current}`)

        for (const quad of subjectQuads) {
          cbd.push(quad)

          // If object is a blank node, add it to processing queue
          if (quad.object.termType === "BlankNode") {
            toProcess.push(quad.object.value)
          }
        }
      }

      console.log(`Total CBD quads: ${cbd.length}`)
      set({ cbd })
    } catch (error) {
      console.error("Error getting CBD:", error)
      set({ cbd: [] })
    }
  },
}))

// Fonction pour extraire les préfixes d'une requête SPARQL
function extractPrefixesFromQuery(query) {
  const prefixRegex = /PREFIX\s+(\w+):\s+<([^>]+)>/gi
  const prefixes = []
  let match

  while ((match = prefixRegex.exec(query)) !== null) {
    prefixes.push({
      prefix: match[1],
      uri: match[2],
    })
  }

  return prefixes
}

// Fonction pour trouver les préfixes manquants dans le graphe
function findMissingPrefixes(prefixesInQuery, graph) {
  // Cette fonction est simplifiée car N3.js ne stocke pas directement les préfixes
  // Dans une implémentation réelle, il faudrait vérifier les préfixes dans le graphe
  return prefixesInQuery
}

// Fonction pour ajouter les préfixes manquants au graphe
function addMissingPrefixesToGraph(graph, missingPrefixes) {
  // Ajouter les préfixes manquants au graphe
  for (const prefix of missingPrefixes) {
    console.log(`Adding missing prefix to graph: ${prefix.prefix} -> ${prefix.uri}`)
    // Dans une implémentation réelle, il faudrait ajouter les préfixes au graphe
    // Mais N3.js ne stocke pas directement les préfixes, donc on ajoute des triplets de base
    try {
      // Utiliser DataFactory directement au lieu de require
      const { namedNode, literal, quad } = DataFactory

      // Ajouter un triplet de base pour ce préfixe
      graph.addQuad(
        quad(
          namedNode(`${prefix.uri}dummy`),
          namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
          namedNode("http://www.w3.org/2000/01/rdf-schema#Resource"),
        ),
      )
    } catch (error) {
      console.error(`Error adding prefix ${prefix.prefix} to graph:`, error)
    }
  }
}

// Fonction améliorée pour déterminer le type de requête SPARQL
function getQueryType(query) {
  // Nettoyer la requête pour une meilleure détection
  const cleanQuery = query
    .replace(/^\s+|\s+$/g, "")
    .replace(/\s+/g, " ")
    .toUpperCase()

  // Rechercher les mots-clés au début de la requête ou après un préfixe
  const prefixPattern = /^(PREFIX\s+[^\n]+\s+)*/i
  const withoutPrefixes = cleanQuery.replace(prefixPattern, "")

  // Vérifier les différents types de requêtes
  if (withoutPrefixes.startsWith("SELECT")) return "SELECT"
  if (withoutPrefixes.startsWith("ASK")) return "ASK"
  if (withoutPrefixes.startsWith("CONSTRUCT")) return "CONSTRUCT"
  if (withoutPrefixes.startsWith("DESCRIBE")) return "DESCRIBE"

  // Vérifier les requêtes de mise à jour
  if (withoutPrefixes.includes("INSERT") || withoutPrefixes.includes("DELETE")) return "UPDATE"

  // Si aucun type n'est reconnu, essayer de détecter en fonction de la structure
  if (withoutPrefixes.includes("WHERE") && withoutPrefixes.includes("?")) return "SELECT"

  // Par défaut, considérer comme SELECT
  return "SELECT"
}

// Fonction pour obtenir l'en-tête Accept approprié selon le type de requête
function getAcceptHeaderForQueryType(queryType) {
  switch (queryType) {
    case "SELECT":
    case "ASK":
      return "application/sparql-results+json"
    case "CONSTRUCT":
    case "DESCRIBE":
      return "text/turtle, application/n-triples, application/rdf+xml"
    case "UPDATE":
      return "text/plain"
    default:
      // Par défaut, accepter tous les formats
      return "application/sparql-results+json, text/turtle, application/n-triples, application/rdf+xml, text/plain"
  }
}

// Ajouter cette fonction pour gérer les préfixes courants après la fonction getAcceptHeaderForQueryType
// Elle permettra de résoudre les préfixes localement plutôt que de dépendre des URI externes

function addCommonPrefixes(store) {
  // Ajouter les préfixes courants au store
  const commonPrefixes = {
    rdf: "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
    rdfs: "http://www.w3.org/2000/01/rdf-schema#",
    owl: "http://www.w3.org/2002/07/owl#",
    xsd: "http://www.w3.org/2001/XMLSchema#",
    foaf: "http://xmlns.com/foaf/0.1/",
    dc: "http://purl.org/dc/elements/1.1/",
    dcterms: "http://purl.org/dc/terms/",
    skos: "http://www.w3.org/2004/02/skos/core#",
    ex: "http://example.org/",
    schema: "http://schema.org/",
  }

  // Ajouter quelques triplets de base pour les classes courantes
  try {
    // Utiliser DataFactory directement au lieu de require
    const { namedNode, literal, quad } = DataFactory

    // Ajouter des définitions de base pour FOAF
    store.addQuad(
      quad(
        namedNode("http://xmlns.com/foaf/0.1/Person"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://www.w3.org/2000/01/rdf-schema#Class"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://xmlns.com/foaf/0.1/name"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#Property"),
      ),
    )

    // Ajouter des définitions pour example.org
    store.addQuad(
      quad(
        namedNode("http://example.org/informatique"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://www.w3.org/2000/01/rdf-schema#Class"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudieDans"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#Property"),
      ),
    )

    // Ajouter quelques données d'exemple
    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant1"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://xmlns.com/foaf/0.1/Person"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant1"),
        namedNode("http://xmlns.com/foaf/0.1/name"),
        literal("Jean Dupont"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant1"),
        namedNode("http://example.org/etudieDans"),
        namedNode("http://example.org/informatique"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant2"),
        namedNode("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"),
        namedNode("http://xmlns.com/foaf/0.1/Person"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant2"),
        namedNode("http://xmlns.com/foaf/0.1/name"),
        literal("Marie Martin"),
      ),
    )

    store.addQuad(
      quad(
        namedNode("http://example.org/etudiant2"),
        namedNode("http://example.org/etudieDans"),
        namedNode("http://example.org/informatique"),
      ),
    )

    console.log("Common prefixes and sample data added to the store")
    return true
  } catch (error) {
    console.error("Error adding common prefixes:", error)
    return false
  }
}

// Fonction améliorée pour traiter la réponse selon le type de requête
async function processResponse(response, queryType) {
  const contentType = response.headers.get("Content-Type") || ""
  console.log("Response content type:", contentType)

  try {
    // Essayer d'abord de traiter comme JSON
    if (contentType.includes("json")) {
      const data = await response.json()

      // Pour les requêtes SELECT et ASK
      if (queryType === "SELECT" || queryType === "ASK") {
        // Assurons-nous que le format est correct
        const formattedResults = {
          head: data.head || { vars: [] },
          results: data.results || { bindings: [] },
        }

        // Ajouter le booléen pour les requêtes ASK
        if (queryType === "ASK" && data.boolean !== undefined) {
          formattedResults.results.boolean = data.boolean
        }

        return formattedResults
      }

      // Pour d'autres types retournant du JSON
      return {
        head: { vars: [] },
        results: {
          bindings: [],
          rawContent: JSON.stringify(data, null, 2),
          contentType: contentType,
        },
      }
    }
    // Traiter comme texte pour les formats RDF ou autres
    else {
      const text = await response.text()

      // Pour les requêtes CONSTRUCT et DESCRIBE qui retournent du RDF
      if (
        queryType === "CONSTRUCT" ||
        queryType === "DESCRIBE" ||
        contentType.includes("turtle") ||
        contentType.includes("rdf+xml") ||
        contentType.includes("n-triples")
      ) {
        return {
          head: { vars: [] },
          results: {
            bindings: [],
            rdfContent: text,
            contentType: contentType,
          },
        }
      }

      // Fallback pour les autres types de contenu
      return {
        head: { vars: [] },
        results: {
          bindings: [],
          rawContent: text,
          contentType: contentType,
        },
      }
    }
  } catch (error) {
    console.error("Error processing response:", error)

    // En cas d'erreur, essayer de récupérer le contenu brut
    try {
      const text = await response.text()
      return {
        head: { vars: [] },
        results: {
          bindings: [],
          rawContent: text,
          contentType: contentType,
          error: error.message,
        },
      }
    } catch (fallbackError) {
      // Si même cela échoue, retourner une structure minimale
      return {
        head: { vars: [] },
        results: {
          bindings: [],
          error: error.message,
        },
      }
    }
  }
}

// Fonction pour gérer les requêtes SELECT locales
function handleLocalSelectQuery(query, graph) {
  try {
    // Extraction des variables de la requête
    const selectMatch = query.match(/SELECT\s+([^{]+)/i)
    let vars = []

    if (selectMatch && selectMatch[1]) {
      vars = selectMatch[1]
        .trim()
        .split(/\s+/)
        .filter((v) => v.startsWith("?"))
        .map((v) => v.substring(1))
    }

    // Si aucune variable n'est trouvée ou si la requête est mal formée, utilisons des variables par défaut
    if (vars.length === 0) {
      vars = ["subject", "predicate", "object"]
    }

    console.log("Extracted variables:", vars)

    // Amélioration: Analyse plus avancée de la requête pour les fichiers Turtle
    // Extraire les patterns de la clause WHERE
    const whereMatch = query.match(/WHERE\s*{([^}]+)}/i)
    if (whereMatch && whereMatch[1]) {
      const whereClause = whereMatch[1].trim()
      console.log("WHERE clause:", whereClause)

      // Analyser les patterns de triplets
      const patterns = parseTriplePatterns(whereClause)
      console.log("Parsed triple patterns:", patterns)

      // Utiliser les patterns pour filtrer les résultats
      if (patterns.length > 0) {
        return executePatternQuery(graph, patterns, vars)
      }
    }

    // Si l'analyse avancée échoue, revenir à l'approche simplifiée
    const bindings = []
    let count = 0

    // Ensure we have a valid graph with quads
    if (graph.size > 0) {
      graph.forEach((quad) => {
        if (count < 100) {
          // Increased limit for better results
          // Limit to 100 results for simplicity
          const binding = {}

          if (vars.includes("subject")) {
            binding["subject"] = {
              type: "uri",
              value: quad.subject.value,
            }
          }

          if (vars.includes("predicate")) {
            binding["predicate"] = {
              type: "uri",
              value: quad.predicate.value,
            }
          }

          if (vars.includes("object")) {
            binding["object"] = {
              type: quad.object.termType === "Literal" ? "literal" : "uri",
              value: quad.object.value,
              ...(quad.object.datatype && { datatype: quad.object.datatype.value }),
            }
          }

          // Only add if we have at least one matching variable
          if (Object.keys(binding).length > 0) {
            bindings.push(binding)
            count++
          }
        }
      })
    }

    console.log(`Generated ${bindings.length} bindings for query`)

    // Assurons-nous que le format est correct
    return {
      head: { vars },
      results: { bindings },
    }
  } catch (error) {
    console.error("Error in handleLocalSelectQuery:", error)
    // En cas d'erreur, retourner un résultat minimal mais valide
    return {
      head: { vars: ["subject", "predicate", "object"] },
      results: { bindings: [] },
      error: error.message,
    }
  }
}

// Fonction pour analyser les patterns de triplets dans la clause WHERE
function parseTriplePatterns(whereClause) {
  const patterns = []

  // Diviser la clause WHERE en triplets
  const tripletStrings = whereClause.split(/\s*\.\s*/).filter((t) => t.trim())

  for (const tripletString of tripletStrings) {
    // Analyser chaque triplet
    const parts = tripletString.trim().split(/\s+/)

    if (parts.length >= 3) {
      const pattern = {
        subject: parseRdfTerm(parts[0]),
        predicate: parseRdfTerm(parts[1]),
        object: parseRdfTerm(parts.slice(2).join(" ")),
      }
      patterns.push(pattern)
    }
  }

  return patterns
}

// Fonction pour analyser un terme RDF (URI, littéral ou variable)
function parseRdfTerm(term) {
  term = term.trim()

  // Variable
  if (term.startsWith("?")) {
    return { type: "variable", value: term.substring(1) }
  }

  // URI complète
  if (term.startsWith("<") && term.endsWith(">")) {
    return { type: "uri", value: term.substring(1, term.length - 1) }
  }

  // Préfixe:nom
  if (term.includes(":") && !term.includes("<")) {
    return { type: "prefixed", value: term }
  }

  // Littéral
  if (term.startsWith('"') && (term.endsWith('"') || term.includes('"^^'))) {
    return { type: "literal", value: term }
  }

  // Par défaut, considérer comme un terme inconnu
  return { type: "unknown", value: term }
}

// Fonction pour exécuter une requête basée sur des patterns
function executePatternQuery(graph, patterns, vars) {
  const bindings = []

  // Pour chaque quad dans le graphe
  graph.forEach((quad) => {
    // Vérifier si le quad correspond à l'un des patterns
    for (const pattern of patterns) {
      if (matchesPattern(quad, pattern)) {
        // Créer un binding pour ce quad
        const binding = {}

        // Remplir les variables demandées
        for (const varName of vars) {
          if (varName === "subject" && pattern.subject.type === "variable") {
            binding[pattern.subject.value] = {
              type: "uri",
              value: quad.subject.value,
            }
          }

          if (varName === "predicate" && pattern.predicate.type === "variable") {
            binding[pattern.predicate.value] = {
              type: "uri",
              value: quad.predicate.value,
            }
          }

          if (varName === "object" && pattern.object.type === "variable") {
            binding[pattern.object.value] = {
              type: quad.object.termType === "Literal" ? "literal" : "uri",
              value: quad.object.value,
              ...(quad.object.datatype && { datatype: quad.object.datatype.value }),
            }
          }
        }

        // Ajouter le binding s'il contient au moins une variable
        if (Object.keys(binding).length > 0) {
          bindings.push(binding)
        }
      }
    }
  })

  return {
    head: { vars },
    results: { bindings },
  }
}

// Fonction pour vérifier si un quad correspond à un pattern
function matchesPattern(quad, pattern) {
  // Vérifier le sujet
  if (pattern.subject.type !== "variable") {
    if (pattern.subject.type === "uri" && quad.subject.value !== pattern.subject.value) {
      return false
    }
    if (pattern.subject.type === "prefixed") {
      // Traitement simplifié des préfixes
      const prefixedValue = expandPrefixedName(pattern.subject.value)
      if (prefixedValue && quad.subject.value !== prefixedValue) {
        return false
      }
    }
  }

  // Vérifier le prédicat
  if (pattern.predicate.type !== "variable") {
    if (pattern.predicate.type === "uri" && quad.predicate.value !== pattern.predicate.value) {
      return false
    }
    if (pattern.predicate.type === "prefixed") {
      // Traitement simplifié des préfixes
      const prefixedValue = expandPrefixedName(pattern.predicate.value)
      if (prefixedValue && quad.predicate.value !== prefixedValue) {
        return false
      }
    }
  }

  // Vérifier l'objet
  if (pattern.object.type !== "variable") {
    if (pattern.object.type === "uri" && quad.object.value !== pattern.object.value) {
      return false
    }
    if (pattern.object.type === "prefixed") {
      // Traitement simplifié des préfixes
      const prefixedValue = expandPrefixedName(pattern.object.value)
      if (prefixedValue && quad.object.value !== prefixedValue) {
        return false
      }
    }
    if (
      pattern.object.type === "literal" &&
      (quad.object.termType !== "Literal" || quad.object.value !== pattern.object.value)
    ) {
      return false
    }
  }

  // Si toutes les conditions sont satisfaites, le quad correspond au pattern
  return true
}

// Fonction pour développer un nom préfixé (ex: foaf:Person -> http://xmlns.com/foaf/0.1/Person)
function expandPrefixedName(prefixedName) {
  const commonPrefixes = {
    rdf: "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
    rdfs: "http://www.w3.org/2000/01/rdf-schema#",
    owl: "http://www.w3.org/2002/07/owl#",
    xsd: "http://www.w3.org/2001/XMLSchema#",
    foaf: "http://xmlns.com/foaf/0.1/",
    dc: "http://purl.org/dc/elements/1.1/",
    dcterms: "http://purl.org/dc/terms/",
    skos: "http://www.w3.org/2004/02/skos/core#",
    ex: "http://example.org/",
    schema: "http://schema.org/",
  }

  const [prefix, local] = prefixedName.split(":")

  if (commonPrefixes[prefix]) {
    return commonPrefixes[prefix] + local
  }

  return null
}

// Fonction pour gérer les requêtes ASK locales
function handleLocalAskQuery(query, graph) {
  try {
    // Implémentation simplifiée - retourne toujours true si le graphe a des données
    const hasData = graph.size > 0

    return {
      head: {},
      results: {
        bindings: [],
        boolean: hasData,
      },
    }
  } catch (error) {
    console.error("Error in handleLocalAskQuery:", error)
    return {
      head: {},
      results: {
        bindings: [],
        boolean: false,
      },
      error: error.message,
    }
  }
}

// Fonction pour gérer les requêtes CONSTRUCT et DESCRIBE locales
function handleLocalConstructQuery(query, graph, queryType) {
  try {
    // Implémentation simplifiée - retourne un sous-ensemble du graphe au format texte
    let turtleContent = "@prefix ex: <http://example.org/> .\n"
    let count = 0

    graph.forEach((quad) => {
      if (count < 20) {
        // Limiter à 20 triplets pour la simplicité
        turtleContent += `<${quad.subject.value}> <${quad.predicate.value}> `

        if (quad.object.termType === "NamedNode") {
          turtleContent += `<${quad.object.value}>`
        } else {
          turtleContent += `"${quad.object.value}"`
          if (quad.object.datatype) {
            turtleContent += `^^<${quad.object.datatype.value}>`
          }
        }

        turtleContent += " .\n"
        count++
      }
    })

    return {
      head: { vars: [] },
      results: {
        bindings: [],
        rdfContent: turtleContent,
        contentType: "text/turtle",
      },
    }
  } catch (error) {
    console.error("Error in handleLocalConstructQuery:", error)
    return {
      head: { vars: [] },
      results: {
        bindings: [],
        rdfContent: "@prefix ex: <http://example.org/> .\n# Error generating RDF content",
        contentType: "text/turtle",
      },
      error: error.message,
    }
  }
}

// Fonction pour gérer les requêtes UPDATE locales
function handleLocalUpdateQuery(query, graph) {
  // Implémentation simplifiée - ne modifie pas réellement le graphe
  return {
    head: { vars: [] },
    results: {
      bindings: [],
      rawContent: "Update operation not supported in local mode. The graph remains unchanged.",
      contentType: "text/plain",
    },
  }
}

// Hook pour utiliser le store RDF uniquement côté client
export function useClientRdfStore() {
  const isBrowser = useBrowser()
  const store = useRdfStore()

  // Retourner une version sécurisée du store qui ne fait rien côté serveur
  if (!isBrowser) {
    return {
      ...store,
      connectToEndpoint: async () => {
        console.warn("Cannot connect to endpoint on server-side")
        return Promise.resolve()
      },
      executeQuery: async () => {
        console.warn("Cannot execute query on server-side")
        return Promise.resolve({ head: { vars: [] }, results: { bindings: [] } })
      },
    }
  }

  return store
}
